<?php

namespace freeme120;

//기본 클레스
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat;

//이벤트
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;

//커맨드
use pocketmine\command\CommandSender;
use pocketmine\command\Command;

//베이스클레스
use pocketmine\item\Item;
use pocketmine\block\Block;
use pocketmine\Player;

//백터
use pocketmine\math\Vector3;
use pocketmine\entity\Effect;
use pocketmine\utils\Config;
use pocketmine\level\Position;

//연동
use onebone\economyapi\EconomyAPI;

class CookieRun extends PluginBase implements Listener{
	public $config;
	public $db;
	
	public $players;
	public $pdb;
	
	public $stage;
	public $sdb;
	
	public function onEnable(){
		@mkdir($this->getDataFolder());
		$this->config = new Config ($this->getDataFolder () . "config.yml", Config::YAML, [
			"C랭크-가격" => 5000,
			"B랭크-가격" => 50000,
			"A랭크-가격" => 100000,
			"S랭크-가격" => 500000,
			"레전더리-가격" => 1000000,
			"이벤트-가격" => 5000000,
			"재료상자-가격" => 5000,
			"사탕재료-가격" => 5000
		]);
		$this->db = $this->config->getAll();
		$this->players = new Config ($this->getDataFolder () . "players.yml", Config::YAML);
		$this->pdb = $this->players->getAll();
		$this->stage = new Config ( $this->getDataFolder () . "stage.yml", Config::YAML );
		$this->sdb = $this->stage->getAll();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§6[ 쿠키런 ]§f 쿠키런 플러그인이 활성화 되었습니다.");
		$this->getLogger()->info("§6[ 경고 ]§f 해당 플러그인의 저작권은 프리미에게 있습니다. 무단사용/무단복제/무단공유/무단판매는 금지합니다.");
	}
	
	public function onDisable(){
		$this->getLogger()->info("§6[ 쿠키런 ]§f 쿠키런 플러그인이 비활성화 되었습니다.");
	}
	public function onHeld(PlayerItemHeldEvent $event) {
		$player = $event->getPlayer();
		$id = $player->getInventory()->getItemInHand()->getId();
		$meta = $player->getInventory()->getItemInHand()->getDamage();
		if ($id == 264) {
			$player->sendPopup("§l§6[ 쿠키런 ]§r§f 크리스탈");
		}
		if ($id == 452){
			$player->sendPopup("§l§6[ 쿠키런 ]§r§f 10코인");
		}
		if ($id == 265){
			$player->sendPopup("§l§6[ 쿠키런 ]§r§f 10코인");
		}
		if ($id == 371){
			$player->sendPopup("§l§6[ 쿠키런 ]§r§f 100코인");
		}
		if ($id == 266){
			$player->sendPopup("§l§6[ 쿠키런 ]§r§f 500코인");
		}
		if ($id == 351 && $meta == 0){//용감한
			$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        }
        if ($id == 351 && $meta == 1){//명량한
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        }
        if ($id == 351 && $meta == 2){//딸기맛
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        }
        if ($id == 351 && $meta == 3){//쿠키앤크림
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 30);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        }
        if ($id == 351 && $meta == 4){//구름맛
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 5);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        }
        if ($id == 351 && $meta == 7){//커피
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        }
        if ($id == 351 && $meta == 11){//보더
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(3);
            $player->addEffect($effect);
        }
        if ($id == 351 && $meta == 8){//용사
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        }
        if ($id == 351 && $meta == 9){//근육
        	$effect = Effect::getEffect(2);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(3);
            $player->addEffect($effect);
        }
        if ($id == 351 && $meta == 10){//좀비
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 50);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 50);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        }
        if ($id == 288){//피겨여왕
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(3);
            $player->addEffect($effect);
        }
        if ($id == 340){//연금술사
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        }
        if ($id == 336){//음유시인
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 30);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 30);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        }
        if ($id == 337){//체리맛
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 30);
            $effect->setAmplifier(3);
            $player->addEffect($effect);
        }
        if ($id == 396){//천사
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(4);
            $player->addEffect($effect);
        }
        if ($id == 334){//버블껌
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 5);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 5);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
            $effect = Effect::getEffect(5);
            $effect->setDuration(20 * 5);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        }
        if ($id == 372){//악마맛
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 4);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 4);
            $effect->setAmplifier(3);
            $player->addEffect($effect);
            $effect = Effect::getEffect(14);
            $effect->setDuration(20 * 4);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        }
        if ($id == 433 && $meta == 15){//뱀파이어
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 1);
            $effect->setAmplifier(3);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 1);
            $effect->setAmplifier(3);
            $player->addEffect($effect);
        }
        if ($id == 432){//블랙베리
        	$effect = Effect::getEffect(14);
            $effect->setDuration(20 * 2);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        }
        if ($id == 318){//달빛술사
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(3);
            $player->addEffect($effect);
            $effect = Effect::getEffect(5);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        }
        if ($id == 377){//불꽃정령
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 15);
            $effect->setAmplifier(5);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 15);
            $effect->setAmplifier(5);
            $player->addEffect($effect);
        }
        if ($id == 420){//정글전사
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 10);
            $effect->setAmplifier(7);
            $player->addEffect($effect);
        }
        if ($id == 445){//어둠마녀
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
            $effect = Effect::getEffect(3);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
            $effect = Effect::getEffect(14);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        }
        if ($id == 351 && $meta == 12){//의적
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(3);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(5);
            $effect->setDuration(20 * 15);
            $effect->setAmplifier(3);
            $player->addEffect($effect);
            $effect = Effect::getEffect(3);
            $effect->setDuration(20 * 15);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
            $effect = Effect::getEffect(14);
            $effect->setDuration(20 * 15);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        }
        if ($id == 351 && $meta == 14){//구미호
        	$effect = Effect::getEffect(1);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
        	$effect = Effect::getEffect(8);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(2);
            $player->addEffect($effect);
            $effect = Effect::getEffect(5);
            $effect->setDuration(20 * 20);
            $effect->setAmplifier(1);
            $player->addEffect($effect);
        }
	}
	public function onJoin(PlayerJoinEvent $event){
		$name = $event->getPlayer()->getName();
		if (!isset($this->pdb [$name] )){
			$this->pdb [$name] = [ ];
			$this->pdb [$name] ["뜨거운돌"] = 0;
			$this->pdb [$name] ["차가운돌"] = 0;
			$this->pdb [$name] ["어둠의조각"] = 0;
			$this->pdb [$name] ["꿈속의별가루"] = 0;
			$this->pdb [$name] ["누군가의꼬리"] = 0;
			$this->pdb [$name] ["톡톡탄산방울"] = 0;
			$this->pdb [$name] ["커피가루"] = 0;
			$this->pdb [$name] ["사탕"] = 0;
			$this->pdb [$name] ["점수"] = 0;
			$this->saveData();
		}
	}
	public function onChangeStage(PlayerMoveEvent $event){
		$player = $event->getPlayer();
		$name = $player->getName();
		$block = $player->level->getBlock(new Vector3((int) $player->x, (int) ($player->y - 1), (int) $player->z));
		$bid = $block->getId();
		$bmeta = $block->getDamage();
		if($bid == 35 && $bmeta == 1){
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 1스테이지 클리어 ~!");
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 코인: +5 / 점수: +5");
			$this->getServer()->broadcastMessage("§l§6[ 알림 ]§r§e {$name}님§f께서 1스테이지를 클리어 하였습니다.");
			$this->pdb [$name] ["점수"] += 5;
			$player->getInventory()->addItem(Item::get(452, 0, 5));
			$p = explode ( ':', $this->sdb ["2스테이지"] );
			$player->teleport ( new Position ( $p [0], ($p [1] + 0.3), $p [2], $this->getServer ()->getLevelByName ( $p [3] ) ) );
		}
		if($bid == 35 && $bmeta == 2){
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 2스테이지 클리어 ~!");
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 코인: +10 / 점수: +10");
			$this->getServer()->broadcastMessage("§l§6[ 알림 ]§r§e {$name}님§f께서 2스테이지를 클리어 하였습니다.");
			$this->pdb [$name] ["점수"] += 10;
			$player->getInventory()->addItem(Item::get(452, 0, 10));
			$p = explode ( ':', $this->sdb ["3스테이지"] );
			$player->teleport ( new Position ( $p [0], ($p [1] + 0.3), $p [2], $this->getServer ()->getLevelByName ( $p [3] ) ) );
		}
		if($bid == 35 && $bmeta == 3){
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 3스테이지 클리어 ~!");
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 코인: +15 / 점수: +15");
			$this->getServer()->broadcastMessage("§l§6[ 알림 ]§r§e {$name}님§f께서 3스테이지를 클리어 하였습니다.");
			$this->pdb [$name] ["점수"] += 15;
			$player->getInventory()->addItem(Item::get(452, 0, 15));
			$p = explode ( ':', $this->sdb ["4스테이지"] );
			$player->teleport ( new Position ( $p [0], ($p [1] + 0.3), $p [2], $this->getServer ()->getLevelByName ( $p [3] ) ) );
		}
		if($bid == 35 && $bmeta == 4){
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 4스테이지 클리어 ~!");
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 코인: +20 / 점수: +20");
			$this->getServer()->broadcastMessage("§l§6[ 알림 ]§r§e {$name}님§f께서 4스테이지를 클리어 하였습니다.");
			$this->pdb [$name] ["점수"] += 20;
			$player->getInventory()->addItem(Item::get(452, 0, 20));
			$p = explode ( ':', $this->sdb ["5스테이지"] );
			$player->teleport ( new Position ( $p [0], ($p [1] + 0.3), $p [2], $this->getServer ()->getLevelByName ( $p [3] ) ) );
		}
		if($bid == 35 && $bmeta == 5){
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 5스테이지 클리어 ~!");
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 코인: +25 / 점수: +25");
			$this->getServer()->broadcastMessage("§l§6[ 알림 ]§r§e {$name}님§f께서 5스테이지를 클리어 하였습니다.");
			$this->pdb [$name] ["점수"] += 25;
			$player->getInventory()->addItem(Item::get(452, 0, 25));
			$p = explode ( ':', $this->sdb ["6스테이지"] );
			$player->teleport ( new Position ( $p [0], ($p [1] + 0.3), $p [2], $this->getServer ()->getLevelByName ( $p [3] ) ) );
		}
		if($bid == 35 && $bmeta == 6){
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 6스테이지 클리어 ~!");
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 코인: +30 / 점수: +30");
			$this->getServer()->broadcastMessage("§l§6[ 알림 ]§r§e {$name}님§f께서 6스테이지를 클리어 하였습니다.");
			$this->pdb [$name] ["점수"] += 30;
			$player->getInventory()->addItem(Item::get(452, 0, 30));
			$p = explode ( ':', $this->sdb ["7스테이지"] );
			$player->teleport ( new Position ( $p [0], ($p [1] + 0.3), $p [2], $this->getServer ()->getLevelByName ( $p [3] ) ) );
		}
		if($bid == 35 && $bmeta == 7){
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 7스테이지 클리어 ~!");
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 코인: +35 / 점수: +35");
			$this->getServer()->broadcastMessage("§l§6[ 알림 ]§r§e {$name}님§f께서 7스테이지를 클리어 하였습니다.");
			$this->pdb [$name] ["점수"] += 35;
			$player->getInventory()->addItem(Item::get(452, 0, 35));
			$p = explode ( ':', $this->sdb ["8스테이지"] );
			$player->teleport ( new Position ( $p [0], ($p [1] + 0.3), $p [2], $this->getServer ()->getLevelByName ( $p [3] ) ) );
		}
		if($bid == 35 && $bmeta == 8){
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 8스테이지 클리어 ~!");
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 코인: +40 / 점수: +40");
			$this->getServer()->broadcastMessage("§l§6[ 알림 ]§r§e {$name}님§f께서 8스테이지를 클리어 하였습니다.");
			$this->pdb [$name] ["점수"] += 40;
			$player->getInventory()->addItem(Item::get(452, 0, 40));
			$p = explode ( ':', $this->sdb ["1스테이지"] );
			$player->teleport ( new Position ( $p [0], ($p [1] + 0.3), $p [2], $this->getServer ()->getLevelByName ( $p [3] ) ) );
		}
	}
	public function onDeath(PlayerMoveEvent $event){
		$player = $event->getPlayer();
		$block = $player->level->getBlock(new Vector3((int) $player->x, (int) ($player->y - 1), (int) $player->z));
		$bid = $block->getId();
		$bmeta = $block->getDamage();
		if($bid == 7){
			$player->sendMessage("§l§6[ 쿠키런 ]§r§f 윽.... 장애물을 밟아 버렸다..");
			$player->setHealth(0);
		}
		/*
		y죄표 1칸위에 있을시 체력 0으로 사망
		장애물을 비슷하게 사용하면 좋을것 같다.
		*/
		if($bid == 35){
			$player->getInventory()->addItem(Item::get(353, 0, 1));
			$player->sendTip("§l§6[ 쿠키런 ]§r§f 설탕 1개를 얻으셨습니다.");
		}
		/*
		y좌표 1칸위에 있을시 설탕 1개를 얻는다.
		잠수대로 돈을 얻게 사용하면 좋을것 같다.
		*/
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args): bool {
		$name = $sender->getName();
		$command = $command->getName();
		$money = EconomyAPI::getInstance()->myMoney($sender);
		$specialBox = EconomyAPI::getInstance()->reduceMoney($sender, $this->db ["재료상자-가격"]);
		$cMoney = EconomyAPI::getInstance()->reduceMoney($sender, $this->db ["C랭크-가격"]);
		$bMoney = EconomyAPI::getInstance()->reduceMoney($sender, $this->db ["B랭크-가격"]);
		$aMoney = EconomyAPI::getInstance()->reduceMoney($sender, $this->db ["A랭크-가격"]);
		$sMoney = EconomyAPI::getInstance()->reduceMoney($sender, $this->db ["S랭크-가격"]);
		if ($command == "쿠키런"){
			if (!isset($args [0])){
				$sender->sendMessage("§l§6[ 쿠키런 ]§r§f /쿠키런 구매 <쿠키명> - 쿠키를 구매합니다.");
				$sender->sendMessage("§l§6[ 쿠키런 ]§r§f /쿠키런 재료상자구매 - 재료상자를 구매합니다.");
				$sender->sendMessage("§l§6[ 쿠키런 ]§r§f /쿠키런 사탕재료구매 - 사탕재료를 구매합니다.");
				$sender->sendMessage("§l§6[ 쿠키런 ]§r§f /쿠키런 설정 <스테이지> : 스테이지를 설정합니다.");
				$sender->sendMessage("§l§6[ 쿠키런 ]§r§f /쿠키런 내점수 : 내점수를 확인합니다.");
				$sender->sendMessage("§l§6[ 쿠키런 ]§r§f /쿠키런 내가방 : 내 재료가방을 확인합니다.");
				return true;
			}
			switch ($args [0]) {
				case "내가방" :
					$sender->sendMessage("§l§6[ 가방 ]§r§f 뜨거운돌:§e " . $this->pdb [$name] ["뜨거운돌"] . "§f개");
					$sender->sendMessage("§l§6[ 가방 ]§r§f 차가운돌:§e " . $this->pdb [$name] ["차가운돌"] . "§f개");
					$sender->sendMessage("§l§6[ 가방 ]§r§f 어둠의조각:§e " . $this->pdb [$name] ["어둠의조각"] . "§f개");
					$sender->sendMessage("§l§6[ 가방 ]§r§f 꿈속의별가루:§e " . $this->pdb [$name] ["꿈속의별가루"] . "§f개");
					$sender->sendMessage("§l§6[ 가방 ]§r§f 누군가의꼬리:§e " . $this->pdb [$name] ["누군가의꼬리"] . "§f개");
					$sender->sendMessage("§l§6[ 가방 ]§r§f 톡톡탄산방울:§e " . $this->pdb [$name] ["톡톡탄산방울"] . "§f개");
					$sender->sendMessage("§l§6[ 가방 ]§r§f 커피가루:§e " . $this->pdb [$name] ["커피가루"] . "§f개");
					$sender->sendMessage("§l§6[ 가방 ]§r§f 사탕:§e " . $this->pdb [$name] ["사탕"] . "§f개");
					break;
				case "내점수" :
					$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 현재 내점수:§e " . $this->pdb [$name] ["점수"] . "점§f입니다.");
					break;
				case "사탕재료구매" :
					if ($money <= $this->db ["사탕재료-가격"]){
						$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다.");
						return true;
					}
					$random = mt_rand(0, 1);
					if($random == 0){
						$this->pdb [$name] ["사탕"] += 1;
						$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 사탕 §b1§f개를 구매하였습니다.");
						$this->saveData();
					}
					if($random == 1){
						$this->pdb [$name] ["사탕"] += 2;
						$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 사탕 §b1+1§f개를 구매하였습니다.");
						return true;
						$this->saveData();
					}
					return true;
				case "재료상자구매" :
					if ($money <= $this->db ["재료상자-가격"]){
						$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다.");
						return true;
					}
					$random = mt_rand(0, 6);
					if($random == 0){
						$sender->sendMessage("§l§b[ 쿠키런 ]§r§b 뜨거운 돌§f이(가) §b1§f개을(를) 획득하셨습니다.");
						$this->pdb [$name] ["뜨거운돌"] += 1;
						$special;
						$this->saveData();
					}
					if($random == 1){
						$sender->sendMessage("§l§b[ 쿠키런 ]§r§b 차가운 돌§f이(가) §b1§f개을(를) 획득하셨습니다.");
						$this->pdb [$name] ["차가운돌"] += 1;
						$special;
						$this->saveData();
					}
					if($random == 2){
						$sender->sendMessage("§l§b[ 쿠키런 ]§r§b 꿈속의 별가루§f이(가) §b1§f개을(를) 획득하셨습니다.");
						$this->pdb [$name] ["꿈속의별가루"] += 1;
						$special;
						$this->saveData();
					}
					if($random == 3){
						$sender->sendMessage("§l§b[ 쿠키런 ]§r§b 누군가의 꼬리§f이(가) §b1§f개을(를) 획득하셨습니다.");
						$this->pdb [$name] ["누군가의꼬리"] += 1;
						$special;
						$this->saveData();
					}
					if($random == 4){
						$sender->sendMessage("§l§b[ 쿠키런 ]§r§b 톡톡탄산방울§f이(가) §b1§f개을(를) 획득하셨습니다.");
						$this->pdb [$name] ["톡톡탄산방울"] += 1;
						$special;
						$this->saveData();
					}
					if($random == 5){
						$sender->sendMessage("§l§b[ 쿠키런 ]§r§b 커피가루§f이(가) §b1§f개을(를) 획득하셨습니다.");
						$this->pdb [$name] ["커피가루"] += 1;
						$special;
						$this->saveData();
					}
					if($random == 6){
						$sender->sendMessage("§l§b[ 쿠키런 ]§r§b 어둠의 조각§f이(가) §b1§f개을(를) 획득하셨습니다.");
						$this->pdb [$name] ["어둠의조각"] += 1;
						$special;
						$this->saveData();
						return true;
					}
					return true;
				case "설정":
				    if(!$sender->isOp()){
					    $sender->sendMessage("§l§6[ 쿠키런 ]§r§f 권한이 없습니다.");
					    return true;
				    }
					if(!isset($args[1])){
						$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 스테이지 번호를 입력해주세요");
						return true;
					}
					switch ($args[1]){
						case "1":
							$x = $sender->getX();
							$y = $sender->getY();
							$z = $sender->getZ();
							$lv = $sender->getLevel()->getFolderName();
							$this->sdb ["1스테이지"] = $x . ":" . $y . ":" . $z . ":" . $lv;
							$this->saveData();
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 1스테이지를 설정하였습니다.");
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 설정좌표: {$x}:{$y}:{$z}");
							break;
						case "2":
							$x = $sender->getX();
							$y = $sender->getY();
							$z = $sender->getZ();
							$lv = $sender->getLevel()->getFolderName();
							$this->sdb ["2스테이지"] = $x . ":" . $y . ":" . $z . ":" . $lv;
							$this->saveData();
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 2스테이지를 설정하였습니다.");
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 설정좌표: {$x}:{$y}:{$z}");
							break;
						case "3":
							$x = $sender->getX();
							$y = $sender->getY();
							$z = $sender->getZ();
							$lv = $sender->getLevel()->getFolderName();
							$this->sdb ["3스테이지"] = $x . ":" . $y . ":" . $z . ":" . $lv;
							$this->saveData();
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 3스테이지를 설정하였습니다.");
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 설정좌표: {$x}:{$y}:{$z}");
							break;
						case "4":
							$x = $sender->getX();
							$y = $sender->getY();
							$z = $sender->getZ();
							$lv = $sender->getLevel()->getFolderName();
							$this->sdb ["4스테이지"] = $x . ":" . $y . ":" . $z . ":" . $lv;
							$this->saveData();
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 4스테이지를 설정하였습니다.");
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 설정좌표: {$x}:{$y}:{$z}");
							break;
						case "5":
							$x = $sender->getX();
							$y = $sender->getY();
							$z = $sender->getZ();
							$lv = $sender->getLevel()->getFolderName();
							$this->sdb ["5스테이지"] = $x . ":" . $y . ":" . $z . ":" . $lv;
							$this->saveData();
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 5스테이지를 설정하였습니다.");
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 설정좌표: {$x}:{$y}:{$z}");
							break;
						case "6":
							$x = $sender->getX();
							$y = $sender->getY();
							$z = $sender->getZ();
							$lv = $sender->getLevel()->getFolderName();
							$this->sdb ["6스테이지"] = $x . ":" . $y . ":" . $z . ":" . $lv;
							$this->saveData();
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 6스테이지를 설정하였습니다.");
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 설정좌표: {$x}:{$y}:{$z}");
							break;
						case "7":
							$x = $sender->getX();
							$y = $sender->getY();
							$z = $sender->getZ();
							$lv = $sender->getLevel()->getFolderName();
							$this->sdb ["7스테이지"] = $x . ":" . $y . ":" . $z . ":" . $lv;
							$this->saveData();
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 7스테이지를 설정하였습니다.");
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 설정좌표: {$x}:{$y}:{$z}");
							break;
						case "8":
							$x = $sender->getX();
							$y = $sender->getY();
							$z = $sender->getZ();
							$lv = $sender->getLevel()->getFolderName();
							$this->sdb ["8스테이지"] = $x . ":" . $y . ":" . $z . ":" . $lv;
							$this->saveData();
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 8스테이지를 설정하였습니다.");
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 설정좌표: {$x}:{$y}:{$z}");
							return true;
					}
					return true;
				case "구매" :
					if(!isset($args[1])){
						$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 올바른 쿠키명을 입력해주세요.");
						return true;
					}
					switch ($args[1]){
						case "용감한":
							if($money <= $this->db ["C랭크-가격"]){
								$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다!");
								return true;
							}
							$CN = new Item(351, 0, 1);
							$CN->setCustomName("§l§7[ C랭크 ]§r§f 용간한맛 쿠키§r");
							$CN->setLore(["§f무엇이든 긍적적인 생각이 있다."]);
							$sender->getInventory()->addItem($CN);
							$sender->sendMessage("§l§6[ 쿠키런 ]§r§6 C랭크 용감한맛 쿠키§f을(를) 구매하셨습니다.");
							$cMoney;
							$this->saveData();
							break;
						case "명량한":
							if($money <= $this->db ["C랭크-가격"]){
								$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다!");
								return true;
							}
							$CN = new Item(351, 1, 1);
							$CN->setCustomName("§l§7[ C랭크 ]§r§f 명량한맛 쿠키§r");
							$CN->setLore(["§f상냥하며 친절하게 대한다."]);
							$sender->getInventory()->addItem($CN);
							$sender->sendMessage("§l§b[ 쿠키런 ]§r§b C랭크 명량한맛 쿠키§f을(를) 구매하셨습니다.");
							$cMoney;
							$this->saveData();
							break;
						case "딸기맛":
							if($money <= $this->db ["B랭크-가격"]){
								$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다!");
								return true;
							}
							$CN = new Item(351, 2, 1);
							$CN->setCustomName("§l§6[ B랭크 ]§r§f 딸기맛 쿠키§r");
							$CN->setLore(["§f달콤하며 땀을 흘린다."]);
							$sender->getInventory()->addItem($CN);
							$sender->sendMessage("§l§b[ 쿠키런 ]§r§b B랭크 딸기맛 쿠키§f을(를) 구매하셨습니다.");
							$bMoney;
							$this->saveData();
							break;
						case "쿠키앤크림":
							if($money <= $this->db ["B랭크-가격"]){
								$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다!");
								return true;
							}
							$CN = new Item(351, 3, 1);
							$CN->setCustomName("§l§6[ B랭크 ]§r§f 쿠키앤크림맛 쿠키§r");
							$CN->setLore(["§f쿠키와 크림의 조합 쿠키"]);
							$sender->getInventory()->addItem($CN);
							$sender->sendMessage("§l§b[ 쿠키런 ]§r§b B랭크 쿠키앤크림맛 쿠키§f을(를) 구매하셨습니다.");
							$bMoney;
							$this->saveData();
							break;
						case "구름맛":
							if($money <= $this->db ["B랭크-가격"]){
								$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다!");
								return true;
							}
							$CN = new Item(351, 4, 1);
							$CN->setCustomName("§l§6[ B랭크 ]§r§f 구름맛 쿠키§r");
							$CN->setLore(["§f둥실둥실 날아오를것만 같다."]);
							$sender->getInventory()->addItem($CN);
							$sender->sendMessage("§l§b[ 쿠키런 ]§r§b B랭크 구름맛 쿠키§f을(를) 구매하셨습니다.");
							$bMoney;
							$this->saveData();
							break;
						case "버터크림":
							if($money <= $this->db ["B랭크-가격"]){
								$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다!");
								return true;
							}
							$CN = new Item(351, 5, 1);
							$CN->setCustomName("§l§6[ B랭크 ]§r§f 버터크림맛 쿠키§r");
							$CN->setLore(["§f느끼함의 끝판왕"]);
							$sender->getInventory()->addItem($CN);
							$sender->sendMessage("§l§b[ 쿠키런 ]§r§b B랭크 버터크림맛 쿠키§f을(를) 구매하셨습니다.");
							$bMoney;
							$this->saveData();
							break;
						case "커피맛":
							if($money <= $this->db ["A랭크-가격"]){
								$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다!");
								return true;
							}
							$CN = new Item(351, 7, 1);
							$CN->setCustomName("§l§6[ A랭크 ]§r§f 커피맛 쿠키§r");
							$CN->setLore(["§f역시 모닝커피는 꿀맛"]);
							$sender->getInventory()->addItem($CN);
							$sender->sendMessage("§l§b[ 쿠키런 ]§r§b A랭크 커피맛 쿠키§f을(를) 구매하셨습니다.");
							$aMoney;
							$this->saveData();
							break;
						case "보더맛":
							if($money <= $this->db ["A랭크-가격"]){
								$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다!");
								return true;
							}
							$CN = new Item(351, 11, 1);
							$CN->setCustomName("§l§6[ A랭크 ]§r§f 보더맛 쿠키§r");
							$CN->setLore(["§f쌩쌩하게 달리는 기분~!"]);
							$sender->getInventory()->addItem($CN);
							$sender->sendMessage("§l§b[ 쿠키런 ]§r§b A랭크 보더맛 쿠키§f을(를) 구매하셨습니다.");
							$aMoney;
							$this->saveData();
							break;
						case "공주맛":
							if($money <= $this->db ["A랭크-가격"]){
								$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다!");
								return true;
							}
							$CN = new Item(351, 6, 1);
							$CN->setCustomName("§l§6[ A랭크 ]§r§f 공주맛 쿠키§r");
							$CN->setLore(["§f나로 말할거~?"]);
							$sender->getInventory()->addItem($CN);
							$sender->sendMessage("§l§b[ 쿠키런 ]§r§b A랭크 공주맛 쿠키§f을(를) 구매하셨습니다.");
							$aMoney;
							$this->saveData();
							break;
						case "용사":
							if($money <= $this->db ["A랭크-가격"]){
								$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다!");
								return true;
							}
							$CN = new Item(351, 8, 1);
							$CN->setCustomName("§l§6[ A랭크 ]§r§f 용사맛 쿠키§r");
							$CN->setLore(["§f날 막을 자는 없다."]);
							$sender->getInventory()->addItem($CN);
							$sender->sendMessage("§l§b[ 쿠키런 ]§r§b A랭크 용사맛 쿠키§f을(를) 구매하셨습니다.");
							$aMoney;
							$this->saveData();
							break;
						case "근육맛":
							if($money <= $this->db ["A랭크-가격"]){
								$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다!");
								return true;
							}
							$CN = new Item(351, 9, 1);
							$CN->setCustomName("§l§6[ A랭크 ]§r§f 근육맛 쿠키§r");
							$CN->setLore(["§f어디 힘좀 써볼까?"]);
							$sender->getInventory()->addItem($CN);
							$sender->sendMessage("§l§b[ 쿠키런 ]§r§b A랭크 근육맛 쿠키§f을(를) 구매하셨습니다.");
							$aMoney;
							$this->saveData();
							break;
						case "좀비":
							if($money <= $this->db ["A랭크-가격"]){
								$sender->sendMessage("§l§6[ 쿠키런 ]§r§f 돈이 부족합니다!");
								return true;
							}
							$CN = new Item(351, 10, 1);
							$CN->setCustomName("§l§6[ A랭크 ]§r§f 좀비맛 쿠키§r");
							$CN->setLore(["§f꾸예에에에엙"]);
							$sender->getInventory()->addItem($CN);
							$sender->sendMessage("§l§b[ 쿠키런 ]§r§b A랭크 좀비맛 쿠키§f을(를) 구매하셨습니다.");
							$aMoney;
							$this->saveData();
							return true;
						break;
					}
			}
		}
	}
	public function saveData() {
		$this->config->setAll($this->db);
		$this->config->save();
		$this->players->setAll($this->pdb);
		$this->players->save();
		$this->stage->setAll($this->sdb);
		$this->stage->save();
	}
}//클레스 괄호
?>